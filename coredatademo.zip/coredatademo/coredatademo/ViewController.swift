//
//  ViewController.swift
//  coredatademo
//
//  Created by Ronit on 11/23/20.
//  Copyright © 2020 Ronit. All rights reserved.
//

import UIKit
import CoreData


class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {
    var userisupdate : Bool = false
     var peoplelist: [NSManagedObject] = []
    var usersendtitle = ""
    var usersendsummary = ""
   var imagesend: UIImage!
    @IBOutlet var btnnewpage: UIButton!
    var arraylist = [String]()
    @IBOutlet var tabllist: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        tabllist.dataSource = self
        tabllist.delegate = self
        tabllist.estimatedRowHeight = 20.0
        tabllist.rowHeight = UITableView.automaticDimension
        self.fetchAllPersons()
        
    }
   func fetchAllPersons(){
      guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
        return
      }
      
      /*Before you can do anything with Core Data, you need a managed object context. */
      let managedContext = appDelegate.persistentContainer.viewContext
      
      /*As the name suggests, NSFetchRequest is the class responsible for fetching from Core Data.
       
       Initializing a fetch request with init(entityName:), fetches all objects of a particular entity. This is what you do here to fetch all Person entities.
       */
      let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Testentity")
      
      /*You hand the fetch request over to the managed object context to do the heavy lifting. fetch(_:) returns an array of managed objects meeting the criteria specified by the fetch request.*/
      do {
        peoplelist = try managedContext.fetch(fetchRequest)
        if peoplelist.count > 0
        {
            
        }
        else
        {
            
        }
        tabllist.reloadData()
      } catch let error as NSError {
        print("Could not fetch. \(error), \(error.userInfo)")
      }
      
    }
    @IBAction func btnnewpage(_ sender: Any)
    {
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(0), execute:
              {
                  self.performSegue(withIdentifier: "Seguetoadd", sender: nil)
              })
    }
    func  tableView(_ tableView: UITableView, estimatedHeightForRowAt indexPath: IndexPath) -> CGFloat {
         return tableView.rowHeight
    }

      
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {

        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return peoplelist.count
       }
       
       func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let samplecell = tableView.dequeueReusableCell(withIdentifier: "newCell", for: indexPath) as! TablelistCell

//        samplecell.lbltitle.text = "title here"
         let person = peoplelist[indexPath.row]
        samplecell.lblsummary.text = person.value(forKeyPath: "txtsummary") as? String
        samplecell.lbltitle.text = person.value(forKeyPath: "testtitled") as? String
        if let imageData = person.value(forKey: "imgpro") as? NSData {
            if let image = UIImage(data:imageData as Data) {
                samplecell.imgpro.image = image
            }
        }
           return samplecell
       }
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }


  func tableView(_ tableView: UITableView,
                   leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
        let editAction = UIContextualAction(style: .normal, title:  "Update", handler: { (ac:UIContextualAction, view:UIView, success:(Bool) -> Void) in
                success(true)
            self.userisupdate = true
            let person = self.peoplelist[indexPath.row]
            self.usersendtitle = (person.value(forKeyPath: "testtitled") as? String)!
            self.usersendsummary = (person.value(forKeyPath: "txtsummary") as? String)!
            if let imageData = person.value(forKey: "imgpro") as? NSData {
                   if let image = UIImage(data:imageData as Data) {
                    self.imagesend = image
                   }
            }
            DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(0), execute:
             {
                 self.performSegue(withIdentifier: "Seguetoadd", sender: nil)
             })
            })
     editAction.backgroundColor = .gray

            return UISwipeActionsConfiguration(actions: [editAction])
    }
    func tableView(_ tableView: UITableView,
                   trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration?
    {
         let person = peoplelist[indexPath.row]
        let deleteAction = UIContextualAction(style: .normal, title:  "Delete", handler: { (ac:UIContextualAction, view:UIView, success:(Bool) -> Void) in
            success(true)
             /*look at implementation of delete method */
          
            if person.isFault {
               print("empty")
            }
            else {
                print("not empty")
                // your regular view body
            }
            self.delete(person : person as! Testentity)
//            self.deleteRecords()
            /*remove person object from array also, so that datasource have correct data*/
            self.peoplelist.remove(at: (self.peoplelist.firstIndex(of: person)!))
            
            /*Finally reload tableview*/
            self.tabllist.reloadData()
        })
        deleteAction.backgroundColor = .red

        return UISwipeActionsConfiguration(actions: [deleteAction])
    }
   func deleteRecords() -> Void {
    guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
            return
          }
        let managedContext = appDelegate.persistentContainer.viewContext
       let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "Testentity")

        let result = try? managedContext.fetch(fetchRequest)
           let resultData = result as! [Testentity]

           for object in resultData {
               managedContext.delete(object)
           }

           do {
               try managedContext.save()
               print("saved!")
           } catch let error as NSError  {
               print("Could not save \(error), \(error.userInfo)")
           } catch {

           }

   }
    func delete(person : Testentity){
       // Assuming type has a reference to managed object context
       
       // Assuming that a specific NSManagedObject's objectID property is accessible
       // Alternatively, could supply a predicate expression that's precise enough
       // to select only a _single_ entity
       
       guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
         return
       }
       let managedContext = appDelegate.persistentContainer.viewContext
       
       do {
         managedContext.delete(person)
       } catch {
         // Do something in response to error condition
       }
       
       do {
         try managedContext.save()
       } catch {
         // Do something in response to error condition
       }
     }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if (segue.identifier == "Seguetoadd" && userisupdate == true )
        {
            let vc = segue.destination as! AddViewController
            vc.usercheckstatus = userisupdate
            vc.usrtitle = usersendtitle
            vc.usrsummary = usersendsummary
            vc.imagesendadded = imagesend
        }
        else
        {
            
        }
    }
   
}

