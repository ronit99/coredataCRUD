//
//  AddViewController.swift
//  coredatademo
//
//  Created by Ronit on 11/23/20.
//  Copyright © 2020 Ronit. All rights reserved.
//

import UIKit
import CoreData


class AddViewController: UIViewController,UINavigationControllerDelegate, UIImagePickerControllerDelegate {
    @IBOutlet var imageView: UIImageView!
    @IBOutlet var chooseBuuton: UIButton!
    var imagePicker = UIImagePickerController()
    var usercheckstatus : Bool = false
    var usrsummary = ""
    var usrtitle = ""
     var imagesendadded: UIImage!
    @IBOutlet var txtsummary: UITextView!
    @IBOutlet var txttitle: UITextField!
   var userlist = [String]()
    var people: [NSManagedObject] = []
    override func viewDidLoad() {
          super.viewDidLoad()
        if usercheckstatus == false
        {
                
        }
        else
        {
            txtsummary.text = usrsummary
            txttitle.text = usrtitle
            imageView.image = imagesendadded
        }
          // Do any additional setup after loading the view.
      }
    @IBAction func btnchooseimage(_ sender: Any) {
        if UIImagePickerController.isSourceTypeAvailable(UIImagePickerController.SourceType.photoLibrary){
            print("Button capture")
            let imag = UIImagePickerController()
            imag.delegate = self
            imag.sourceType = UIImagePickerController.SourceType.photoLibrary;
            //imag.mediaTypes = [kUTTypeImage];
            imag.allowsEditing = false
            self.present(imag, animated: true, completion: nil)
        }
    }
   
   func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {

        guard let selectedImage = info[UIImagePickerController.InfoKey.originalImage] as? UIImage else {
            fatalError("Expected a dictionary containing an image, but was provided the following: \(info)")
        }

        imageView.image = selectedImage
        dismiss(animated: true, completion: nil)
    }
    func fetchAllPersons(){
       guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
         return
       }
       
       /*Before you can do anything with Core Data, you need a managed object context. */
       let managedContext = appDelegate.persistentContainer.viewContext
       
       /*As the name suggests, NSFetchRequest is the class responsible for fetching from Core Data.
        
        Initializing a fetch request with init(entityName:), fetches all objects of a particular entity. This is what you do here to fetch all Person entities.
        */
       let fetchRequest = NSFetchRequest<NSManagedObject>(entityName: "Testentity")
       
       /*You hand the fetch request over to the managed object context to do the heavy lifting. fetch(_:) returns an array of managed objects meeting the criteria specified by the fetch request.*/
       do {
         people = try managedContext.fetch(fetchRequest)
       } catch let error as NSError {
         print("Could not fetch. \(error), \(error.userInfo)")
       }
       
     }
    func save(name: String, txtsummary : String) {
       guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else {
         return
       }
       
       /*1.
        Before you can save or retrieve anything from your Core Data store, you first need to get your hands on an NSManagedObjectContext. You can consider a managed object context as an in-memory “scratchpad” for working with managed objects.
        Think of saving a new managed object to Core Data as a two-step process: first, you insert a new managed object into a managed object context; then, after you’re happy with your shiny new managed object, you “commit” the changes in your managed object context to save it to disk.
        Xcode has already generated a managed object context as part of the new project’s template. Remember, this only happens if you check the Use Core Data checkbox at the beginning. This default managed object context lives as a property of the NSPersistentContainer in the application delegate. To access it, you first get a reference to the app delegate.
        */
       let managedContext = appDelegate.persistentContainer.viewContext
       
       /*
        An NSEntityDescription object is associated with a specific class instance
        Class
        NSEntityDescription
        A description of an entity in Core Data.
        
        Retrieving an Entity with a Given Name here person
        */
       let entity = NSEntityDescription.entity(forEntityName: "Testentity",
                                               in: managedContext)!
       
        /*
        Initializes a managed object and inserts it into the specified managed object context.
        
        init(entity: NSEntityDescription,
        insertInto context: NSManagedObjectContext?)
        */
       let person = NSManagedObject(entity: entity,
                                    insertInto: managedContext)
       
       /*
        With an NSManagedObject in hand, you set the name attribute using key-value coding. You must spell the KVC key (name in this case) exactly as it appears in your Data Model
        */
       person.setValue(name, forKeyPath: "testtitled")
       person.setValue(txtsummary, forKeyPath: "txtsummary")
        let imgData = imageView.image!.jpegData(compressionQuality: 1)
        person.setValue(imgData, forKeyPath: "imgpro")
       
       /*
        You commit your changes to person and save to disk by calling save on the managed object context. Note save can throw an error, which is why you call it using the try keyword within a do-catch block. Finally, insert the new managed object into the people array so it shows up when the table view reloads.
        */
       do {
         try managedContext.save()
        people.append(person)
       } catch let error as NSError {
         print("Could not save. \(error), \(error.userInfo)")
       }
     }
      @IBAction func backbtn(_ sender: Any) {
          
      let transition: CATransition = CATransition()
      transition.duration = 0.3
      transition.timingFunction = CAMediaTimingFunction(name: CAMediaTimingFunctionName.default)
      transition.type = CATransitionType.push
      self.view.window!.layer.add(transition, forKey: nil)
      navigationController?.popViewController(animated: true)
      dismiss(animated: false, completion: nil)
          
      }
      @IBAction func btnadd(_ sender: Any) {
        if usercheckstatus == false
        {
            self.save(name: txttitle.text!, txtsummary: txtsummary.text!)
        }
        else
        {
            self.updateData()
        }
        
        self.fetchAllPersons()
        DispatchQueue.main.asyncAfter(deadline: .now() + .seconds(0), execute:
         {
             self.performSegue(withIdentifier: "Seguetolist", sender: nil)
         })
        // Do any additional setup after loading the view.
    }
func updateData(){
   
       //As we know that container is set up in the AppDelegates so we need to refer that container.
       guard let appDelegate = UIApplication.shared.delegate as? AppDelegate else { return }
       
       //We need to create a context from this container
       let managedContext = appDelegate.persistentContainer.viewContext
       
       let fetchRequest:NSFetchRequest<NSFetchRequestResult> = NSFetchRequest.init(entityName: "Testentity")
       fetchRequest.predicate = NSPredicate(format: "testtitled = %@", usrtitle)
       do
       {
        let test = try managedContext.fetch(fetchRequest)
        let objectUpdate = test[0] as! NSManagedObject
        objectUpdate.setValue(txttitle.text!, forKey: "testtitled")
        objectUpdate.setValue(txtsummary.text!, forKey: "txtsummary")
        let imgData = imageView.image!.jpegData(compressionQuality: 1)
        objectUpdate.setValue(imgData, forKeyPath: "imgpro")
               do{
                   try managedContext.save()
                print(objectUpdate)
               }
               catch
               {
                   print(error)
               }
           }
       catch
       {
           print(error)
       }
  
   }
  
}
    
